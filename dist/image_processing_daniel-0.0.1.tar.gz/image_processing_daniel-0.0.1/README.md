# image_processing

Description. 
The package package_name is used to:
	- 
	-

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install package_name
```

## Author
daniel_oliveira

## License
[MIT](https://choosealicense.com/licenses/mit/)